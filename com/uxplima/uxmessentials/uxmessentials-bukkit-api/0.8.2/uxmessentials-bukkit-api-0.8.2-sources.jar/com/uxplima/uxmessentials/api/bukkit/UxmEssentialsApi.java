package com.uxplima.uxmessentials.api.bukkit;

import java.util.Optional;
import java.util.function.Consumer;

import org.bukkit.plugin.Plugin;

import com.uxplima.uxmessentials.api.action.UxmActions;
import com.uxplima.uxmessentials.api.bukkit.menu.MenuApi;
import com.uxplima.uxmessentials.api.query.UxmCommandControlQuery;
import com.uxplima.uxmessentials.api.query.UxmDiscordLinkQuery;
import com.uxplima.uxmessentials.api.query.UxmEconomyQuery;
import com.uxplima.uxmessentials.api.query.UxmHologramsQuery;
import com.uxplima.uxmessentials.api.query.UxmHomesQuery;
import com.uxplima.uxmessentials.api.query.UxmInvRollbackQuery;
import com.uxplima.uxmessentials.api.query.UxmItemworldQuery;
import com.uxplima.uxmessentials.api.query.UxmKitsQuery;
import com.uxplima.uxmessentials.api.query.UxmMessagingQuery;
import com.uxplima.uxmessentials.api.query.UxmModerationQuery;
import com.uxplima.uxmessentials.api.query.UxmNpcQuery;
import com.uxplima.uxmessentials.api.query.UxmPlayerStateQuery;
import com.uxplima.uxmessentials.api.query.UxmPlayerWarpsQuery;
import com.uxplima.uxmessentials.api.query.UxmPlaytimeQuery;
import com.uxplima.uxmessentials.api.query.UxmPresenceQuery;
import com.uxplima.uxmessentials.api.query.UxmRanksQuery;
import com.uxplima.uxmessentials.api.query.UxmRegionsQuery;
import com.uxplima.uxmessentials.api.query.UxmScoreboardQuery;
import com.uxplima.uxmessentials.api.query.UxmSecurityQuery;
import com.uxplima.uxmessentials.api.query.UxmSkinQuery;
import com.uxplima.uxmessentials.api.query.UxmStaffQuery;
import com.uxplima.uxmessentials.api.query.UxmTeleportQuery;
import com.uxplima.uxmessentials.api.query.UxmTradeQuery;
import com.uxplima.uxmessentials.api.query.UxmVanishQuery;
import com.uxplima.uxmessentials.api.query.UxmVaultsQuery;
import com.uxplima.uxmessentials.api.query.UxmVoteQuery;
import com.uxplima.uxmessentials.api.query.UxmWarpsQuery;
import com.uxplima.uxmessentials.api.query.UxmWorldsQuery;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

/**
 * The uxmEssentials developer API, and the one place a consumer starts.
 *
 * <p>There are two ways in, because the two idioms fail differently. When your plugin is guaranteed to enable after
 * uxmEssentials, the Bukkit service registry is enough:
 *
 * <pre>{@code
 * UxmEssentialsApi api = getServer().getServicesManager().load(UxmEssentialsApi.class);
 * if (api == null) {
 *     getLogger().info("uxmEssentials is absent; running without it");
 *     return;
 * }
 * }</pre>
 *
 * <p>When load order is not guaranteed, or you want your registrations restored after uxmEssentials reloads, use
 * the callback form instead. It runs immediately when the API is already up, queues otherwise, and runs again after
 * a reload:
 *
 * <pre>{@code
 * UxmEssentialsApi.whenReady(api -> {
 *     getServer().getPluginManager().registerEvents(new MyListener(), this);
 *     api.menus().registerAction("my-award", click -> click.player().giveExp(100));
 * });
 * }</pre>
 *
 * <h2>Events</h2>
 * Listening needs nothing from this interface: the event classes under {@code com.uxplima.uxmessentials.api.bukkit
 * .event} are ordinary Bukkit events you register a listener for. Everything the plugin does publishes a
 * notification {@code Uxm<Thing><Action>Event}, delivered on the tick thread that owns its subject once the action
 * has happened. The operations that can be refused with nothing half-done also publish a cancellable
 * {@code Uxm<Thing>Pre<Action>Event} beforehand, fired on whichever thread the operation is on; there are nine of
 * them, and they are listed in the developer documentation.
 *
 * <h2>Disabled modules</h2>
 * A disabled module fires no events and answers no queries. Ask {@link #isModuleEnabled(String)} rather than
 * inferring it from silence; nothing here throws merely because a module is off.
 */
@NullMarked
public interface UxmEssentialsApi {

    /** The running uxmEssentials version, for a consumer that would rather feature-detect than hard-fail. */
    String version();

    /**
     * Whether the module with this id is enabled. The id is the one the operator writes in {@code modules.conf},
     * for example {@code homes} or {@code economy}.
     */
    boolean isModuleEnabled(String moduleId);

    /** The menu registration surface: custom actions, requirements, placeholders, list sources and icons. */
    MenuApi menus();

    /**
     * What uxmEssentials can be asked to do, attributed to {@code plugin}.
     *
     * <p>The plugin is required because every write is attributable: its name is what the audit log records, so an
     * operator asking who moved a balance gets an answer. Pass your own {@code JavaPlugin}.
     *
     * <pre>{@code
     * api.actions(this).economy().ifPresent(economy ->
     *     economy.deposit(playerId, new BigDecimal("50")));
     * }</pre>
     */
    UxmActions actions(Plugin plugin);

    /**
     * The same write surface, attributed to {@code plugin} acting on behalf of {@code actingFor}.
     *
     * <p>For a plugin that is a door rather than an actor: a web panel, a Discord bot, a bridge to another server.
     * Its own name is not the useful half of the answer to "who did this", and this lets it say which of its own
     * callers asked. The audit trail records {@code YourPlugin/whoever}, so one bridge's users stay told apart.
     *
     * <pre>{@code
     * api.actions(this, ticket.requestedBy()).economy().ifPresent(economy ->
     *     economy.deposit(playerId, new BigDecimal("50")));
     * }</pre>
     *
     * @param actingFor who your plugin is acting for, in whatever terms your users would recognise
     * @throws IllegalArgumentException when {@code actingFor} is blank, since an attribution nobody can read is
     *     worse than no second half at all
     */
    UxmActions actions(Plugin plugin, String actingFor);

    /**
     * Reading a player's homes, or empty when the homes module is switched off.
     *
     * <p>Empty means the module is off, which is not the same thing as a player having no homes and is worth telling
     * apart: one is a server that will never answer, the other is a player who has not set one yet.
     */
    Optional<UxmHomesQuery> homes();

    /** Reading the server's warps, or empty when the warps module is switched off. */
    Optional<UxmWarpsQuery> warps();

    /** Reading the warps players own, or empty when the player-warps module is switched off. */
    Optional<UxmPlayerWarpsQuery> playerWarps();

    /** Reading balances and the leaderboard, or empty when the economy module is switched off. */
    Optional<UxmEconomyQuery> economy();

    /** Reading the kit catalogue and what a player may claim, or empty when the kits module is switched off. */
    Optional<UxmKitsQuery> kits();

    /** Reading a player's vaults, or empty when the vaults module is switched off. */
    Optional<UxmVaultsQuery> vaults();

    /** Reading punishments and history, or empty when the moderation module is switched off. */
    Optional<UxmModerationQuery> moderation();

    /** Reading who is away from their keyboard, or empty when the presence module is switched off. */
    Optional<UxmPresenceQuery> presence();

    /** Reading who is hidden and from whom, or empty when the vanish module is switched off. */
    Optional<UxmVanishQuery> vanish();

    /** Reading how long players have been on the server, or empty when the player-state module is switched off. */
    Optional<UxmPlaytimeQuery> playtime();

    /** Reading the switches held for an online player, or empty when the player-state module is switched off. */
    Optional<UxmPlayerStateQuery> playerState();

    /** Reading the managed worlds and their entry rules, or empty when the worlds module is switched off. */
    Optional<UxmWorldsQuery> worlds();

    /** Reading teleport requests and return points, or empty when the teleport module is switched off. */
    Optional<UxmTeleportQuery> teleport();

    /** Reading where players stand on the rank ladder, or empty when the ranks module is switched off. */
    Optional<UxmRanksQuery> ranks();

    /** Reading the trades open right now, or empty when the trade module is switched off. */
    Optional<UxmTradeQuery> trade();

    /** Reading who is linked to which Discord account, or empty when the discordlink module is switched off. */
    Optional<UxmDiscordLinkQuery> discordLink();

    /** Reading what WorldGuard protects, or empty when the regions module is switched off. */
    Optional<UxmRegionsQuery> regions();

    /** Reading the inventory snapshots held for a player, or empty when the invrollback module is switched off. */
    Optional<UxmInvRollbackQuery> invRollback();

    /** Reading the skin a player chose, or empty when the skin module is switched off. */
    Optional<UxmSkinQuery> skin();

    /** Reading which accounts hold a second factor, or empty when the security module is switched off. */
    Optional<UxmSecurityQuery> security();

    /** Reading vote counts and party progress, or empty when the vote module is switched off. */
    Optional<UxmVoteQuery> vote();

    /** Reading mail, ignores and the messaging switches, or empty when the messaging module is switched off. */
    Optional<UxmMessagingQuery> messaging();

    /** Reading which NPCs exist and where, or empty when the npc module is switched off. */
    Optional<UxmNpcQuery> npc();

    /** Reading which holograms exist and what they say, or empty when the holograms module is switched off. */
    Optional<UxmHologramsQuery> holograms();

    /** Reading who is on duty, or empty when the staff module is switched off. */
    Optional<UxmStaffQuery> staff();

    /** Reading a player's powertool bindings, or empty when the itemworld module is switched off. */
    Optional<UxmItemworldQuery> itemworld();

    /** Asking whether a command is gated, or empty when the commandcontrol module is switched off. */
    Optional<UxmCommandControlQuery> commandControl();

    /** Reading whether a player put their sidebar away, or empty when the scoreboard module is switched off. */
    Optional<UxmScoreboardQuery> scoreboard();

    /** The API, or {@code null} when uxmEssentials is absent, still loading, or shutting down. */
    static @Nullable UxmEssentialsApi get() {
        return UxmApiHolder.current();
    }

    /**
     * Run {@code consumer} as soon as the API is available: immediately when it already is, otherwise once
     * uxmEssentials finishes enabling. The callback runs again after uxmEssentials reloads, so registrations made
     * inside it are restored rather than quietly lost.
     */
    static void whenReady(Consumer<UxmEssentialsApi> consumer) {
        UxmApiHolder.whenReady(consumer);
    }
}
